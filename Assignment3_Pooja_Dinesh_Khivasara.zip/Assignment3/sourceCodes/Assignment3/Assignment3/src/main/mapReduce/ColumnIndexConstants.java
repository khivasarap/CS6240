package main.mapReduce;
/*Defines column numbers in the headers (Used FlightDataHeader file given.)*/
public class ColumnIndexConstants {
	public static int YEAR_COLUMN = 0;
	public static int MONTH_COLUMN = 2;
	public static int FLIGHT_DATE_COLUMN = 5;
	public static int ORIGIN_COLUMN = 11;
	public static int DEST_COLUMN = 17;
	public static int DEP_TIME_COLUMN = 24;
	public static int ARR_TIME_COLUMN = 35;
	public static int ARR_DELAY_MINUTES_COLUMN = 37;
	public static int CANCELLED_COLUMN = 41;
	public static int DIVERTED_COLUMN = 43;
}
