package main.mapReduce;

import java.io.IOException;
import java.util.HashMap;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class WordCount {

	/*
	 * The Mapper implementation, via the map method, processes one line at a time,
	 * as provided by the specified TextInputFormat. It then splits the line into
	 * tokens separated by whitespaces, via the StringTokenizer, and emits a
	 * key-value pair of < <word>, 1>. Reference:
	 * https://hadoop.apache.org/docs/stable/hadoop-mapreduce-client/hadoop-
	 * mapreduce-client-core/MapReduceTutorial.html
	 */
	public static class TokenizerMapper extends Mapper<Object, Text, Text, IntWritable> {

		private final static IntWritable one = new IntWritable(1);

		private Text word = new Text();

		/*
		 * The input to mapper is key and value. The key is the position in the file
		 * that is been processed. The value is the text present on the
		 * line. Ex: Key: 100663363 Value: our Union is strong. 
		 * Reference 1: I have printed and verified it.
		 * Reference 2: hadoop's documentation :
		 * https://hadoop.apache.org/docs/current/api/org/apache/hadoop/mapreduce/lib/
		 * input/TextInputFormat.html An InputFormat for plain text files. Files are
		 * broken into lines. Either linefeed or carriage-return are used to signal end
		 * of line. Keys are the position in the file, and values are the line of text.
		 */
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			HashMap<Text,Integer> map = new HashMap<>();
			StringTokenizer itr = new StringTokenizer(value.toString());
			while (itr.hasMoreTokens()) {
				word.set(itr.nextToken());
				/* Convert value to lower case. */
				String s = word.toString().toLowerCase();
				/*
				 * Check if converted value starts with any other following: m,n,o,p,q If yes,
				 * remove punctuation and emit it.
				 */
				if (Character.isLetter(s.charAt(0)) && (s.startsWith("m") || s.startsWith("n") || s.startsWith("o")
						|| s.startsWith("p") || s.startsWith("q"))) {
					// Exclude punctuation marks excepts - and '
					String w = word.toString().replaceAll("[\\p{Punct}&&[^'-]]+", "");
					map.put(new Text(w), map.getOrDefault(new Text(w), 0) + 1);
				}
			}
			// Emit all the values in <word,count> from hashmap.
			for(Text wordKey: map.keySet()) {
				context.write(wordKey,new IntWritable(map.get(wordKey)));
			}
		}
	}

	public static class IntSumReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
		private IntWritable result = new IntWritable();

		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			int sum = 0;
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}
	}

	public static class CustomWordPartitioner extends Partitioner<Text, IntWritable> {
		@Override
		public int getPartition(Text key, IntWritable value, int numPartitions) {
			String partitionKey = key.toString().toLowerCase();
			if (partitionKey.charAt(0) == 'm') {
				return 0;
			} else if (partitionKey.charAt(0) == 'n') {
				return 1;
			} else if (partitionKey.charAt(0) == 'o') {
				return 2;
			} else if (partitionKey.charAt(0) == 'p') {
				return 3;
			} else if (partitionKey.charAt(0) == 'q') {
				return 4;
			}
			return 0;
		}

	}
	// Program using PerMapTally
	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "word count");
		job.setJarByClass(WordCount.class);
		job.setNumReduceTasks(5);
		job.setPartitionerClass(CustomWordPartitioner.class);
		job.setMapperClass(TokenizerMapper.class);
		//job.setCombinerClass(IntSumReducer.class);
		job.setReducerClass(IntSumReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
