package main.mapReduce;
/*Defines constants used for filtering and validation*/
public class FlightConstants {
	public static String ORIGIN_ORD = "ORD";
	public static String DESTINATION_JFK = "JFK";
	public static Integer START_MONTH = 06;
	public static Integer START_YEAR = 2007;
	public static Integer END_MONTH = 05;
	public static Integer END_YEAR = 2008;
	public static String NOT_CANCELLED = "1.00";
	public static String NOT_DIVERTED = "1.00";
	public static Integer FILE_HEADERS = 56;
}
