package main.mapReduce;

import java.io.IOException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import com.opencsv.CSVParser;

public class FlightDelayCalculator {
	/**
	 * Mapper class to apply projection on the flight data
	 */
	private static final String F1 = "F1";
	private static final String F2 = "F2";

	/* To have Context Global counters. Reference: https://diveintodata.org/2011/03/15/an-example-of-hadoop-mapreduce-counter/*/
	public enum ContextCounters {
		TOTAL_FLIGHT_DELAY_IN_MINS, TOTAL_FREQUENCY;
	}

	/*
	 * The purpose of the custom mapper is map the input csv file into required
	 * (key,value) pairs The input csv consists of multiple rows and columns
	 * separated by comma. Please note that all attributes we need for our
	 * computation do exist in all the input files and are in the exact same column.
	 * Thus, we can use column position to locate required field in the data.
	 * 
	 * Another decision to make here is Key: Since logically we join the F1 and F2
	 * data on: middleStop and flightDate (should be same for F1 and F2) this is
	 * considered as key. Thus, Key emitted will be : "middleStop#flightDate" or
	 * "F2#middleStop#flightDate". At a later stage, we can partition the data on
	 * F(1 or 2) and year and thus F1 and F2 is added. As part of this
	 * implementation, keeping it simple.
	 * 
	 * Next point to think about how the reducer input will look like: It needs to
	 * process : 1. whether it's first leg flight(F1) or second-leg flight (F2) 2.
	 * Check the arrivalTime of F1 Vs Departure Time of F2. 3. DelayInMins required
	 * for computation. Thus, these are emitted as part of values from mapper.
	 */
	public static class CustomMapper extends Mapper<Object, Text, Text, Text> {

		// Initialize CSVParser as comma separated values
		private CSVParser csvParser = new CSVParser();

		/**
		 * Key : Byte offset from where the line is being read value : string
		 * representing the entire line of flight data
		 */
		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {

			// Tokenize on comma using CSV Reader and get the tokens on the line.
			String[] tokens = this.csvParser.parseLine(value.toString());
			Text mapperKey = new Text();
			Text mapperValue = new Text();

			// Ensure we have correct tokens and valid conditions. Do selection first.
			if (isValidRecord(tokens)) {
				// Create Valid Flight record with useful information
				/*
				 * We know that flight is valid. Now we have know if it's first-leg or
				 * second-leg. For flight to be first-leg (F1), it's origin = ORD and
				 * destination is anything except JFK. For flight to be second-leg (F2), it's
				 * destination = JFK and origin can be anything except ORD. Thus, for F1 and F2,
				 * our key will be MidStop+FlightDate For Value we will need to know whether
				 * it's F1 or F2, we need to know arrTime of F1 <= depTime of F2 and we need
				 * arrivalDelayInMinutes.
				 */
				String origin = tokens[ColumnIndexConstants.ORIGIN_COLUMN].trim();
				String dest = tokens[ColumnIndexConstants.DEST_COLUMN].trim();
				String flightDate = tokens[ColumnIndexConstants.FLIGHT_DATE_COLUMN].trim();
				String arrivalDelayMinutes = tokens[ColumnIndexConstants.ARR_DELAY_MINUTES_COLUMN].trim();

				if (FlightConstants.ORIGIN_ORD.equals(origin) && !FlightConstants.DESTINATION_JFK.equals(dest)) {
					String middleStop = dest;
					String arrivalTime = tokens[ColumnIndexConstants.ARR_TIME_COLUMN].trim();
					String keyString = middleStop + "#" + flightDate;
					mapperKey.set(keyString);
					String valueString = F1 + "#" + arrivalTime + "#" + arrivalDelayMinutes;
					mapperValue.set(valueString);
				} else if (!FlightConstants.ORIGIN_ORD.equals(origin) && FlightConstants.DESTINATION_JFK.equals(dest)) {
					String middleStop = tokens[ColumnIndexConstants.ORIGIN_COLUMN].trim();
					String depTime = tokens[ColumnIndexConstants.DEP_TIME_COLUMN].trim();
					String keyString = middleStop + "#" + flightDate;
					mapperKey.set(keyString);
					String valueString = F2 + "#" + depTime + "#" + arrivalDelayMinutes;
					mapperValue.set(valueString);
				}
				context.write(mapperKey, mapperValue);
			}
		}

		/*
		 * To check if Flight data is valid and of interest. We need to check the
		 * following: We use FlightDataHeader to check columns and position for
		 * attribute. 1. The Flight should not have origin = ORD and destination = JFK.
		 * This will be a direct flight and not two-leg flight. (Origin attribute on
		 * position 11, Destination attribute on position 17.) 2. Flight is not
		 * cancelled. (Cancelled attribute on 41 position index in tokens) 3. Flight is
		 * not diverted. (Diverted attribute on position 43 position index in tokens) 4.
		 * Flight month-year should be between 06-2007 to 05-2008 (Month attribute 02
		 * position and Year at 0 position.)
		 */
		/*
		 * Projection operation performed first, we consider only columns of interest to
		 * us.
		 */
		private boolean isValidRecord(String[] tokens) {
			if (tokens == null || tokens.length <= 0 || tokens.length != FlightConstants.FILE_HEADERS) {
				return false;
			}
			if (tokens[ColumnIndexConstants.YEAR_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.MONTH_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.FLIGHT_DATE_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.ORIGIN_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.DEST_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.DEP_TIME_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.ARR_TIME_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.ARR_DELAY_MINUTES_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.CANCELLED_COLUMN].isEmpty()
					|| tokens[ColumnIndexConstants.DIVERTED_COLUMN].isEmpty()) {
				return false;
			}
			boolean isCancelled = FlightConstants.NOT_CANCELLED
					.equals(tokens[ColumnIndexConstants.CANCELLED_COLUMN].trim());
			boolean isDiverted = FlightConstants.NOT_DIVERTED
					.equals(tokens[ColumnIndexConstants.DIVERTED_COLUMN].trim());
			if (isCancelled || isDiverted) {
				return false;
			}
			String origin = tokens[ColumnIndexConstants.ORIGIN_COLUMN].trim();
			String dest = tokens[ColumnIndexConstants.DEST_COLUMN].trim();
			if (FlightConstants.ORIGIN_ORD.equals(origin) && FlightConstants.DESTINATION_JFK.equals(dest)) {
				return false;
			}
			String monthValue = tokens[ColumnIndexConstants.MONTH_COLUMN];
			String yearValue = tokens[ColumnIndexConstants.YEAR_COLUMN];
			if (!isValidDate(monthValue, yearValue)) {
				return false;
			}

			return true;
		}

		// To check whether the record date is valid, should be between JUNE,2007 to
		// MAY,2008
		private boolean isValidDate(String monthToken, String yearToken) {
			try {
				int month = Integer.parseInt(monthToken.trim());
				int year = Integer.parseInt(yearToken.trim());
				LocalDate date = LocalDate.of(year, month, 1);
				LocalDate startDate = YearMonth.of(FlightConstants.START_YEAR, FlightConstants.START_MONTH).atDay(1);
				LocalDate endDate = YearMonth.of(FlightConstants.END_YEAR, FlightConstants.END_MONTH).atEndOfMonth();
				if (!date.isBefore(startDate) && !date.isAfter(endDate)) {
					return true;
				}
				return false;
			} catch (NumberFormatException pe) {
				return false;
			}
		}
	}

	/*
	 * Reducer class will create list for oneLeg and secondLeg flight and perform
	 * Join operation.
	 */
	public static class CustomReducer extends Reducer<Text, Text, Text, Text> {

		private int frequency;
		private float totalDelay;

		@Override
		protected void setup(Context context) {
			this.totalDelay = 0;
			this.frequency = 0;
		}

		/**
		 * Reduce call will be made for every unique key value along with the ) * list
		 * of related records
		 */
		public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
			/*
			 * Create List based on whether it's first leg (F1) or secondLeg flight (F2).
			 * The reason to create 2 lists is we have to perform join on each entry by
			 * traversing.
			 */
			List<String> legOneFlights = new ArrayList<String>();
			List<String> legTwoFlights = new ArrayList<String>();

			for (Text val : values) {
				String mapperValue = val.toString();
				if (mapperValue.startsWith("F1")) {
					legOneFlights.add(mapperValue);
				} else {
					legTwoFlights.add(mapperValue);
				}
			}

			// Perform join for F1 and F2
			performJoin(legOneFlights, legTwoFlights);
		}
		
		/* Following Reduce Side-Join pattern from slides */
		private void performJoin(List<String> legOneFlights, List<String> legTwoFlights) {
			for (String legOneFlight : legOneFlights) {
				for (String legTwoFlight : legTwoFlights) {
					String[] legOneFlightTokens = legOneFlight.split("#");
					String[] legTwoFlightTokens = legTwoFlight.split("#");
					if (checkValidFlights(legOneFlightTokens, legTwoFlightTokens)) {
						float delay = Float.parseFloat(legOneFlightTokens[2]) + Float.parseFloat(legTwoFlightTokens[2]);
						this.totalDelay += delay;
						this.frequency++;
					}
				}
			}
		}

		/**
		 * This is to validate F1 has arrived before F2.
		 */
		private boolean checkValidFlights(String[] legOneFlightTokens, String[] legTwoFlightTokens) {
			String arrivalTime = legOneFlightTokens[1];
			String deptTime = legTwoFlightTokens[1];
			if (Integer.parseInt(arrivalTime) < Integer.parseInt(deptTime)) {
				return true;
			}
			return false;
		}

		// Performs global aggregation for delay and frequency and writes to the
		// context.
		protected void cleanup(Context context) throws IOException, InterruptedException {
			context.getCounter(ContextCounters.TOTAL_FLIGHT_DELAY_IN_MINS).increment((long) totalDelay);
			context.getCounter(ContextCounters.TOTAL_FREQUENCY).increment(frequency);

			context.write(
					new Text(context.getCounter(ContextCounters.TOTAL_FLIGHT_DELAY_IN_MINS).getValue() + ""),
					new Text(context.getCounter(ContextCounters.TOTAL_FREQUENCY).getValue() + ""));
		}
	}

	/**
	 * Main method
	 */
	public static void main(String[] args) throws Exception {

		Configuration conf = new Configuration();

		Job job = Job.getInstance(conf, "FlightDelayCalculator");
		job.setJarByClass(FlightDelayCalculator.class);
		job.setMapperClass(CustomMapper.class);
		job.setReducerClass(CustomReducer.class);
		job.setNumReduceTasks(10);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		job.waitForCompletion(true);
		// To compute average sequentially.
		if(job.isSuccessful()) {
			long totalSum = job.getCounters().findCounter(ContextCounters.TOTAL_FLIGHT_DELAY_IN_MINS).getValue();
			long totalFrequency = job.getCounters().findCounter(ContextCounters.TOTAL_FREQUENCY).getValue();
			float average = ((float) totalSum/(float) totalFrequency);
			System.out.println("\nFlight delay information for Two-legged Flights for ORD to JFK : ");
			System.out.println("\nTotal Flight delay in mins : "+ totalSum);
			System.out.println("\nTotal Frequency : "+ totalFrequency);
			System.out.println("\nAverage Flight delay : "+ average);
			System.exit(0);
		} else {
			System.exit(1);
		}
	}
}